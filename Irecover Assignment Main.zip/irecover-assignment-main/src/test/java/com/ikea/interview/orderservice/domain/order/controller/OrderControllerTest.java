package com.ikea.interview.orderservice.domain.order.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import com.ikea.interview.orderservice.domain.order.exception.OrderNotFoundException;
import com.ikea.interview.orderservice.domain.order.handler.OrderHandler;
import com.ikea.interview.orderservice.domain.order.model.*;
import com.ikea.interview.orderservice.domain.order.service.OrderStatisticsService;
import java.math.BigDecimal;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@WebFluxTest(OrderController.class)
class OrderControllerTest {

  @Autowired private WebTestClient webTestClient;

  @MockBean private OrderHandler orderHandler;
  @MockBean private OrderStatisticsService statisticsService;

  private Order testOrder;
  private CreateOrderRequest validRequest;

  @BeforeEach
  void setUp() {
    testOrder =
        Order.builder()
            .id(1L)
            .customerName("John Doe")
            .customerEmail("john@example.com")
            .totalAmount(new BigDecimal("100.00"))
            .status(OrderStatus.PENDING)
            .items(List.of())
            .build();

    validRequest =
        CreateOrderRequest.builder()
            .customerName("John Doe")
            .customerEmail("john@example.com")
            .items(
                List.of(
                    OrderItemRequest.builder()
                        .productName("Test Product")
                        .quantity(2)
                        .unitPrice(new BigDecimal("50.00"))
                        .build()))
            .build();
  }

  @Nested
  @DisplayName("POST /api/v1/orders tests")
  class CreateOrderTests {

    @Test
    @DisplayName("Should return 201 CREATED when order is created")
    void shouldReturn201WhenOrderCreated() {
      when(orderHandler.createOrder(any(CreateOrderRequest.class))).thenReturn(Mono.just(testOrder));

      webTestClient
          .post()
          .uri("/api/v1/orders")
          .contentType(MediaType.APPLICATION_JSON)
          .bodyValue(validRequest)
          .exchange()
          .expectStatus()
          .isCreated()
          .expectBody()
          .jsonPath("$.id")
          .isEqualTo(1)
          .jsonPath("$.customerName")
          .isEqualTo("John Doe");
    }

    @Test
    @DisplayName("Should return 400 when request is invalid")
    void shouldReturn400WhenInvalid() {
      CreateOrderRequest invalidRequest =
          CreateOrderRequest.builder().customerName("").customerEmail("invalid-email").build();

      webTestClient
          .post()
          .uri("/api/v1/orders")
          .contentType(MediaType.APPLICATION_JSON)
          .bodyValue(invalidRequest)
          .exchange()
          .expectStatus()
          .isBadRequest();
    }
  }

  @Nested
  @DisplayName("GET /api/v1/orders tests")
  class GetOrdersTests {

    @Test
    @DisplayName("Should return 200 OK when getting all orders")
    void shouldReturn200WhenGettingAllOrders() {
      when(orderHandler.getAllOrders()).thenReturn(Flux.just(testOrder));

      webTestClient
          .get()
          .uri("/api/v1/orders")
          .exchange()
          .expectStatus()
          .isOk()
          .expectBodyList(Order.class)
          .hasSize(1);
    }

    @Test
    @DisplayName("Should stream multiple orders using Flux")
    void shouldStreamMultipleOrders() {
      Order secondOrder =
          Order.builder()
              .id(2L)
              .customerName("Jane Doe")
              .customerEmail("jane@example.com")
              .totalAmount(new BigDecimal("200.00"))
              .status(OrderStatus.PENDING)
              .items(List.of())
              .build();

      when(orderHandler.getAllOrders()).thenReturn(Flux.just(testOrder, secondOrder));

      webTestClient
          .get()
          .uri("/api/v1/orders")
          .exchange()
          .expectHeader()
          .doesNotExist("Content-Length")
          .expectBodyList(Order.class)
          .hasSize(2)
          .contains(testOrder, secondOrder);
    }

    @Test
    @DisplayName("Should return order by id")
    void shouldReturnOrderById() {
      when(orderHandler.getOrder(1L)).thenReturn(Mono.just(testOrder));

      webTestClient
          .get()
          .uri("/api/v1/orders/1")
          .exchange()
          .expectStatus()
          .isOk()
          .expectBody()
          .jsonPath("$.id")
          .isEqualTo(1);
    }

    @Test
    @DisplayName("Should return 404 JSON error when order not found")
    void shouldReturn404JsonWhenOrderNotFound() {
      when(orderHandler.getOrder(999L))
          .thenReturn(Mono.error(new OrderNotFoundException(999L)));

      webTestClient
          .get()
          .uri("/api/v1/orders/999")
          .exchange()
          .expectStatus()
          .isNotFound()
          .expectHeader()
          .contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
          .expectBody()
          .jsonPath("$.status")
          .isEqualTo(404)
          .jsonPath("$.error")
          .isEqualTo("Not Found")
          .jsonPath("$.message")
          .isNotEmpty();
    }
  }

  @Nested
  @DisplayName("PATCH /api/v1/orders/{id}/status tests")
  class UpdateStatusTests {

    @Test
    @DisplayName("Should update order status")
    void shouldUpdateOrderStatus() {
      Order updatedOrder =
          Order.builder()
              .id(1L)
              .customerName("John Doe")
              .customerEmail("john@example.com")
              .totalAmount(new BigDecimal("100.00"))
              .status(OrderStatus.VALIDATED)
              .items(List.of())
              .build();

      UpdateOrderStatusRequest statusRequest =
          UpdateOrderStatusRequest.builder().status(OrderStatus.VALIDATED).build();

      when(orderHandler.updateStatus(eq(1L), any(UpdateOrderStatusRequest.class)))
          .thenReturn(Mono.just(updatedOrder));

      webTestClient
          .patch()
          .uri("/api/v1/orders/1/status")
          .contentType(MediaType.APPLICATION_JSON)
          .bodyValue(statusRequest)
          .exchange()
          .expectStatus()
          .isOk()
          .expectBody()
          .jsonPath("$.status")
          .isEqualTo("VALIDATED");
    }
  }

  @Nested
  @DisplayName("DELETE /api/v1/orders/{id} tests")
  class DeleteOrderTests {

    @Test
    @DisplayName("Should delete order and return 204")
    void shouldDeleteOrder() {
      when(orderHandler.deleteOrder(1L)).thenReturn(Mono.empty());

      webTestClient
          .delete()
          .uri("/api/v1/orders/1")
          .exchange()
          .expectStatus()
          .isNoContent();
    }
  }
}
