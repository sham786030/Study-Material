package com.ikea.interview.orderservice.domain.order.handler;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import com.ikea.interview.orderservice.domain.order.model.*;
import com.ikea.interview.orderservice.domain.order.service.OrderService;
import java.math.BigDecimal;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
class OrderHandlerTest {

  @Mock private OrderService orderService;

  @InjectMocks private OrderHandler orderHandler;

  private Order testOrder;
  private CreateOrderRequest validRequest;

  @BeforeEach
  void setUp() {
    testOrder =
        Order.builder()
            .id(1L)
            .customerName("John Doe")
            .customerEmail("john@example.com")
            .totalAmount(new BigDecimal("100.00"))
            .status(OrderStatus.PENDING)
            .items(List.of())
            .build();

    validRequest =
        CreateOrderRequest.builder()
            .customerName("John Doe")
            .customerEmail("john@example.com")
            .items(
                List.of(
                    OrderItemRequest.builder()
                        .productName("Test Product")
                        .quantity(2)
                        .unitPrice(new BigDecimal("50.00"))
                        .build()))
            .build();
  }

  @Nested
  @DisplayName("createOrder tests")
  class CreateOrderTests {

    @Test
    @DisplayName("Should create order with valid request")
    void shouldCreateOrderWithValidRequest() {
      when(orderService.createOrder(any(CreateOrderRequest.class))).thenReturn(Mono.just(testOrder));

      StepVerifier.create(orderHandler.createOrder(validRequest))
          .expectNext(testOrder)
          .verifyComplete();

      verify(orderService).createOrder(any(CreateOrderRequest.class));
    }

    @Test
    @DisplayName("Should accept order with exactly 1 item")
    void shouldAcceptOrderWithOneItem() {
      CreateOrderRequest singleItemRequest =
          CreateOrderRequest.builder()
              .customerName("John Doe")
              .customerEmail("john@example.com")
              .items(
                  List.of(
                      OrderItemRequest.builder()
                          .productName("Single Product")
                          .quantity(1)
                          .unitPrice(new BigDecimal("50.00"))
                          .build()))
              .build();

      when(orderService.createOrder(any(CreateOrderRequest.class))).thenReturn(Mono.just(testOrder));

      StepVerifier.create(orderHandler.createOrder(singleItemRequest))
          .expectNext(testOrder)
          .verifyComplete();
    }
  }

  @Nested
  @DisplayName("searchByEmail tests")
  class SearchByEmailTests {

    @Test
    @DisplayName("Should return orders for valid email")
    void shouldReturnOrdersForValidEmail() {
      when(orderService.getOrdersByCustomerEmail("john@example.com"))
          .thenReturn(Flux.just(testOrder));

      StepVerifier.create(orderHandler.searchByEmail("john@example.com"))
          .expectNext(testOrder)
          .verifyComplete();
    }

    @Test
    @DisplayName("Should handle null email gracefully")
    void shouldHandleNullEmail() {
      StepVerifier.create(orderHandler.searchByEmail(null))
          .expectError(IllegalArgumentException.class)
          .verify();
    }

    @Test
    @DisplayName("Should reject empty email")
    void shouldRejectEmptyEmail() {
      StepVerifier.create(orderHandler.searchByEmail(""))
          .expectError(IllegalArgumentException.class)
          .verify();
    }
  }
}
