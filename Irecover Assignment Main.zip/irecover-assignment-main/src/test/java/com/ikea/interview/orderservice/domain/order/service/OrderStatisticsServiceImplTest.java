package com.ikea.interview.orderservice.domain.order.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.ikea.interview.orderservice.domain.order.model.OrderStatistics;
import com.ikea.interview.orderservice.domain.order.repository.OrderRepository;
import com.ikea.interview.orderservice.domain.order.repository.entity.OrderEntity;
import com.ikea.interview.orderservice.domain.order.service.impl.OrderStatisticsServiceImpl;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
class OrderStatisticsServiceImplTest {

  @Mock private OrderRepository orderRepository;

  @InjectMocks private OrderStatisticsServiceImpl statisticsService;

  @Nested
  @DisplayName("getStatistics tests")
  class GetStatisticsTests {

    @Test
    @DisplayName("Should calculate statistics correctly with fulfilled orders")
    void shouldCalculateStatisticsWithFulfilledOrders() {
      OrderEntity order1 =
          OrderEntity.builder()
              .id(1L)
              .customerName("John")
              .customerEmail("john@example.com")
              .totalAmount(new BigDecimal("100.00"))
              .status("FULFILLED")
              .createdAt(LocalDateTime.now())
              .build();

      OrderEntity order2 =
          OrderEntity.builder()
              .id(2L)
              .customerName("Jane")
              .customerEmail("jane@example.com")
              .totalAmount(new BigDecimal("200.00"))
              .status("FULFILLED")
              .createdAt(LocalDateTime.now())
              .build();

      when(orderRepository.findAll()).thenReturn(Flux.just(order1, order2));

      StepVerifier.create(statisticsService.getStatistics())
          .assertNext(
              stats -> {
                assertEquals(2, stats.getTotalOrders());
                assertEquals(2, stats.getFulfilledOrders());
                assertEquals(new BigDecimal("300.00"), stats.getTotalRevenue());
                assertEquals(
                    new BigDecimal("150.00"),
                    stats.getAverageOrderValue(),
                    "Average should be 300/2 = 150.00");
              })
          .verifyComplete();
    }

    /**
     * This test exposes the DIFFICULT BUG - ArithmeticException (division by zero) when there are
     * orders but none of them are fulfilled. The averageOrderValue calculation divides by
     * 'fulfilled' count instead of 'total' count.
     */
    @Test
    @DisplayName("Should handle statistics when no orders are fulfilled")
    void shouldHandleNoFulfilledOrders() {
      OrderEntity pendingOrder =
          OrderEntity.builder()
              .id(1L)
              .customerName("John")
              .customerEmail("john@example.com")
              .totalAmount(new BigDecimal("100.00"))
              .status("PENDING")
              .createdAt(LocalDateTime.now())
              .build();

      OrderEntity cancelledOrder =
          OrderEntity.builder()
              .id(2L)
              .customerName("Jane")
              .customerEmail("jane@example.com")
              .totalAmount(new BigDecimal("200.00"))
              .status("CANCELLED")
              .createdAt(LocalDateTime.now())
              .build();

      when(orderRepository.findAll()).thenReturn(Flux.just(pendingOrder, cancelledOrder));

      StepVerifier.create(statisticsService.getStatistics())
          .assertNext(
              stats -> {
                assertEquals(2, stats.getTotalOrders());
                assertEquals(0, stats.getFulfilledOrders());
                assertEquals(1, stats.getPendingOrders());
                assertEquals(1, stats.getCancelledOrders());
                assertEquals(BigDecimal.ZERO, stats.getTotalRevenue());
                assertEquals(
                    BigDecimal.ZERO,
                    stats.getAverageOrderValue(),
                    "Average should be ZERO when no fulfilled orders");
              })
          .verifyComplete();
    }

    @Test
    @DisplayName("Should handle empty order list")
    void shouldHandleEmptyOrders() {
      when(orderRepository.findAll()).thenReturn(Flux.empty());

      StepVerifier.create(statisticsService.getStatistics())
          .assertNext(
              stats -> {
                assertEquals(0, stats.getTotalOrders());
                assertEquals(BigDecimal.ZERO, stats.getTotalRevenue());
                assertEquals(BigDecimal.ZERO, stats.getAverageOrderValue());
              })
          .verifyComplete();
    }
  }

  @Nested
  @DisplayName("getStatisticsForCustomer tests")
  class GetStatisticsForCustomerTests {

    @Test
    @DisplayName("Should calculate customer statistics correctly")
    void shouldCalculateCustomerStatistics() {
      OrderEntity order1 =
          OrderEntity.builder()
              .id(1L)
              .customerName("John")
              .customerEmail("john@example.com")
              .totalAmount(new BigDecimal("100.00"))
              .status("FULFILLED")
              .createdAt(LocalDateTime.now())
              .build();

      when(orderRepository.findByCustomerEmail("john@example.com")).thenReturn(Flux.just(order1));

      StepVerifier.create(statisticsService.getStatisticsForCustomer("john@example.com"))
          .assertNext(
              stats -> {
                assertEquals(1, stats.getTotalOrders());
                assertEquals(1, stats.getFulfilledOrders());
                assertEquals(new BigDecimal("100.00"), stats.getTotalRevenue());
              })
          .verifyComplete();
    }
  }
}
