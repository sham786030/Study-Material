package com.ikea.interview.orderservice.domain.order.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import com.ikea.interview.orderservice.domain.order.exception.InvalidOrderStateException;
import com.ikea.interview.orderservice.domain.order.exception.OrderNotFoundException;
import com.ikea.interview.orderservice.domain.order.mapper.OrderMapper;
import com.ikea.interview.orderservice.domain.order.model.*;
import com.ikea.interview.orderservice.domain.order.repository.OrderItemRepository;
import com.ikea.interview.orderservice.domain.order.repository.OrderRepository;
import com.ikea.interview.orderservice.domain.order.repository.entity.OrderEntity;
import com.ikea.interview.orderservice.domain.order.repository.entity.OrderItemEntity;
import com.ikea.interview.orderservice.domain.order.service.impl.OrderServiceImpl;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
class OrderServiceImplTest {

  @Mock private OrderRepository orderRepository;
  @Mock private OrderItemRepository orderItemRepository;
  @Mock private OrderMapper orderMapper;

  @InjectMocks private OrderServiceImpl orderService;

  private OrderEntity testOrderEntity;
  private Order testOrder;
  private CreateOrderRequest testCreateRequest;

  @BeforeEach
  void setUp() {
    testOrderEntity =
        OrderEntity.builder()
            .id(1L)
            .customerName("John Doe")
            .customerEmail("john@example.com")
            .totalAmount(new BigDecimal("100.00"))
            .status("PENDING")
            .createdAt(LocalDateTime.now())
            .updatedAt(LocalDateTime.now())
            .build();

    testOrder =
        Order.builder()
            .id(1L)
            .customerName("John Doe")
            .customerEmail("john@example.com")
            .totalAmount(new BigDecimal("100.00"))
            .status(OrderStatus.PENDING)
            .items(List.of())
            .build();

    testCreateRequest =
        CreateOrderRequest.builder()
            .customerName("John Doe")
            .customerEmail("john@example.com")
            .items(
                List.of(
                    OrderItemRequest.builder()
                        .productName("Test Product")
                        .quantity(2)
                        .unitPrice(new BigDecimal("50.00"))
                        .build()))
            .build();
  }

  @Nested
  @DisplayName("getOrderById tests")
  class GetOrderByIdTests {

    @Test
    @DisplayName("Should return order when found")
    void shouldReturnOrderWhenFound() {
      when(orderRepository.findById(1L)).thenReturn(Mono.just(testOrderEntity));
      when(orderItemRepository.findByOrderId(1L)).thenReturn(Flux.empty());
      when(orderMapper.toOrder(testOrderEntity)).thenReturn(testOrder);

      StepVerifier.create(orderService.getOrderById(1L))
          .assertNext(
              order -> {
                assertEquals(1L, order.getId());
                assertEquals("John Doe", order.getCustomerName());
              })
          .verifyComplete();
    }

    @Test
    @DisplayName("Should throw OrderNotFoundException when not found")
    void shouldThrowWhenNotFound() {
      when(orderRepository.findById(999L)).thenReturn(Mono.empty());

      StepVerifier.create(orderService.getOrderById(999L))
          .expectError(OrderNotFoundException.class)
          .verify();
    }
  }

  @Nested
  @DisplayName("updateOrderStatus tests")
  class UpdateOrderStatusTests {

    @Test
    @DisplayName("Should update status when transition is valid (PENDING -> VALIDATED)")
    void shouldUpdateStatusWhenValid() {
      OrderEntity updatedEntity =
          OrderEntity.builder()
              .id(1L)
              .customerName("John Doe")
              .customerEmail("john@example.com")
              .totalAmount(new BigDecimal("100.00"))
              .status("VALIDATED")
              .createdAt(LocalDateTime.now())
              .updatedAt(LocalDateTime.now())
              .build();

      Order updatedOrder =
          Order.builder()
              .id(1L)
              .customerName("John Doe")
              .customerEmail("john@example.com")
              .totalAmount(new BigDecimal("100.00"))
              .status(OrderStatus.VALIDATED)
              .items(List.of())
              .build();

      when(orderRepository.findById(1L)).thenReturn(Mono.just(testOrderEntity));
      when(orderRepository.save(any(OrderEntity.class))).thenReturn(Mono.just(updatedEntity));
      when(orderItemRepository.findByOrderId(1L)).thenReturn(Flux.empty());
      when(orderMapper.toOrder(updatedEntity)).thenReturn(updatedOrder);

      StepVerifier.create(orderService.updateOrderStatus(1L, OrderStatus.VALIDATED, null))
          .assertNext(order -> assertEquals(OrderStatus.VALIDATED, order.getStatus()))
          .verifyComplete();
    }

    @Test
    @DisplayName("Should reject invalid state transition (PENDING -> FULFILLED)")
    void shouldRejectInvalidTransition() {
      when(orderRepository.findById(1L)).thenReturn(Mono.just(testOrderEntity));

      StepVerifier.create(orderService.updateOrderStatus(1L, OrderStatus.FULFILLED, null))
          .expectError(InvalidOrderStateException.class)
          .verify();
    }
  }

  @Nested
  @DisplayName("calculateAndUpdateTotal tests")
  class CalculateTotalTests {

    @Test
    @DisplayName("Should calculate correct total from order items")
    void shouldCalculateCorrectTotal() {
      OrderItemEntity item1 =
          OrderItemEntity.builder()
              .id(1L)
              .orderId(1L)
              .productName("Product A")
              .quantity(2)
              .unitPrice(new BigDecimal("25.00"))
              .build();

      OrderItemEntity item2 =
          OrderItemEntity.builder()
              .id(2L)
              .orderId(1L)
              .productName("Product B")
              .quantity(3)
              .unitPrice(new BigDecimal("10.00"))
              .build();

      // Expected: (25.00 * 2) + (10.00 * 3) = 50.00 + 30.00 = 80.00
      BigDecimal expectedTotal = new BigDecimal("80.00");

      OrderEntity savedEntity =
          OrderEntity.builder()
              .id(1L)
              .customerName("John Doe")
              .customerEmail("john@example.com")
              .totalAmount(expectedTotal)
              .status("PENDING")
              .build();

      Order resultOrder =
          Order.builder()
              .id(1L)
              .totalAmount(expectedTotal)
              .status(OrderStatus.PENDING)
              .items(List.of())
              .build();

      when(orderRepository.findById(1L)).thenReturn(Mono.just(testOrderEntity));
      when(orderItemRepository.findByOrderId(1L)).thenReturn(Flux.just(item1, item2));
      when(orderRepository.save(any(OrderEntity.class))).thenReturn(Mono.just(savedEntity));
      when(orderMapper.toOrderItem(any(OrderItemEntity.class)))
          .thenAnswer(invocation -> {
            OrderItemEntity e = invocation.getArgument(0);
            return OrderItem.builder()
                .id(e.getId())
                .productName(e.getProductName())
                .quantity(e.getQuantity())
                .unitPrice(e.getUnitPrice())
                .build();
          });
      when(orderMapper.toOrder(any(OrderEntity.class))).thenReturn(resultOrder);

      StepVerifier.create(orderService.calculateAndUpdateTotal(1L))
          .assertNext(
              order -> {
                assertEquals(
                    0,
                    expectedTotal.compareTo(order.getTotalAmount()),
                    "Total should be 80.00 but got " + order.getTotalAmount());
              })
          .verifyComplete();
    }
  }
}
