package com.ikea.interview.orderservice.domain.order.exception;

import com.ikea.interview.orderservice.domain.order.model.OrderStatus;

public class InvalidOrderStateException extends RuntimeException {

  public InvalidOrderStateException(OrderStatus currentStatus, OrderStatus targetStatus) {
    super(
        String.format(
            "Cannot transition from %s to %s", currentStatus.name(), targetStatus.name()));
  }

  public InvalidOrderStateException(String message) {
    super(message);
  }
}
