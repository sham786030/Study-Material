package com.ikea.interview.orderservice.domain.order.repository;

import com.ikea.interview.orderservice.domain.order.repository.entity.OrderEntity;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;

@Repository
public interface OrderRepository extends ReactiveCrudRepository<OrderEntity, Long> {

  Flux<OrderEntity> findByStatus(String status);

  Flux<OrderEntity> findByCustomerEmail(String customerEmail);

  @Query("SELECT * FROM orders WHERE customer_name LIKE :name")
  Flux<OrderEntity> searchByCustomerName(String name);
}
