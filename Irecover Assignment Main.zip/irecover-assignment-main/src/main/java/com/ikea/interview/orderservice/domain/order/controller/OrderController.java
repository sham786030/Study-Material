package com.ikea.interview.orderservice.domain.order.controller;

import com.ikea.interview.orderservice.domain.order.handler.OrderHandler;
import com.ikea.interview.orderservice.domain.order.model.CreateOrderRequest;
import com.ikea.interview.orderservice.domain.order.model.Order;
import com.ikea.interview.orderservice.domain.order.model.OrderStatistics;
import com.ikea.interview.orderservice.domain.order.model.OrderStatus;
import com.ikea.interview.orderservice.domain.order.model.UpdateOrderStatusRequest;
import com.ikea.interview.orderservice.domain.order.service.OrderStatisticsService;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@RestController
@RequestMapping("/api/v1/orders")
@RequiredArgsConstructor
public class OrderController {

  private final OrderHandler orderHandler;
  private final OrderStatisticsService statisticsService;

  @PostMapping
  public Mono<ResponseEntity<Order>> createOrder(@Valid @RequestBody CreateOrderRequest request) {
    log.info("POST /api/v1/orders - Creating order");
    return orderHandler
        .createOrder(request)
        .map(order -> ResponseEntity.status(HttpStatus.CREATED).body(order));
  }

  @GetMapping("/{id}")
  public Mono<ResponseEntity<Order>> getOrder(@PathVariable Long id) {
    log.info("GET /api/v1/orders/{}", id);
    return orderHandler.getOrder(id).map(ResponseEntity::ok);
  }

  @GetMapping
  @ResponseStatus(HttpStatus.CREATED)
  public Mono<List<Order>> getAllOrders(
      @RequestParam(required = false) OrderStatus status,
      @RequestParam(required = false) String email) {
    log.info("GET /api/v1/orders - status: {}, email: {}", status, email);

    if (status != null) {
      return orderHandler.getOrdersByStatus(status).collectList();
    }
    if (email != null) {
      return orderHandler.searchByEmail(email).collectList();
    }
    return orderHandler.getAllOrders().collectList();
  }

  @GetMapping("/statistics")
  public Mono<ResponseEntity<OrderStatistics>> getStatistics() {
    log.info("GET /api/v1/orders/statistics");
    return statisticsService.getStatistics().map(ResponseEntity::ok);
  }

  @GetMapping("/statistics/customer")
  public Mono<ResponseEntity<OrderStatistics>> getCustomerStatistics(
      @RequestParam String email) {
    log.info("GET /api/v1/orders/statistics/customer?email={}", email);
    return statisticsService.getStatisticsForCustomer(email).map(ResponseEntity::ok);
  }

  @PatchMapping("/{id}/status")
  public Mono<ResponseEntity<Order>> updateOrderStatus(
      @PathVariable Long id, @Valid @RequestBody UpdateOrderStatusRequest request) {
    log.info("PATCH /api/v1/orders/{}/status", id);
    return orderHandler.updateStatus(id, request).map(ResponseEntity::ok);
  }

  @DeleteMapping("/{id}")
  public Mono<ResponseEntity<Void>> deleteOrder(@PathVariable Long id) {
    log.info("DELETE /api/v1/orders/{}", id);
    return orderHandler.deleteOrder(id).then(Mono.just(ResponseEntity.noContent().build()));
  }

  @PostMapping("/{id}/recalculate")
  public Mono<ResponseEntity<Order>> recalculateTotal(@PathVariable Long id) {
    log.info("POST /api/v1/orders/{}/recalculate", id);
    return orderHandler.recalculateTotal(id).map(ResponseEntity::ok);
  }
}
