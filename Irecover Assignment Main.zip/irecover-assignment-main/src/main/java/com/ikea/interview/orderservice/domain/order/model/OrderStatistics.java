package com.ikea.interview.orderservice.domain.order.model;

import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrderStatistics {

  private long totalOrders;
  private long pendingOrders;
  private long fulfilledOrders;
  private long cancelledOrders;
  private BigDecimal totalRevenue;
  private BigDecimal averageOrderValue;
}
