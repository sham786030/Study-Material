package com.ikea.interview.orderservice.domain.order.model;

public enum OrderStatus {
  PENDING,
  VALIDATED,
  PROCESSING,
  FULFILLED,
  CANCELLED
}
