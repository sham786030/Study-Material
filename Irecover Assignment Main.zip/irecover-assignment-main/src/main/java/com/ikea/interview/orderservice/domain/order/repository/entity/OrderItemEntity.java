package com.ikea.interview.orderservice.domain.order.repository.entity;

import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table("order_items")
public class OrderItemEntity {

  @Id private Long id;

  @Column("order_id")
  private Long orderId;

  @Column("product_name")
  private String productName;

  @Column("quantity")
  private Integer quantity;

  @Column("unit_price")
  private BigDecimal unitPrice;
}
