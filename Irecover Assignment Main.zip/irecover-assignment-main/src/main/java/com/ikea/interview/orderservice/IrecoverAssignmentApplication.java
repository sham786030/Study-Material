package com.ikea.interview.orderservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IrecoverAssignmentApplication {

  public static void main(String[] args) {
    SpringApplication.run(IrecoverAssignmentApplication.class, args);
  }
}
