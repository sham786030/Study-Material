package com.ikea.interview.orderservice.domain.order.handler;

import com.ikea.interview.orderservice.domain.order.model.CreateOrderRequest;
import com.ikea.interview.orderservice.domain.order.model.Order;
import com.ikea.interview.orderservice.domain.order.model.OrderStatus;
import com.ikea.interview.orderservice.domain.order.model.UpdateOrderStatusRequest;
import com.ikea.interview.orderservice.domain.order.service.OrderService;
import com.ikea.interview.orderservice.util.ValidationUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@Component
@RequiredArgsConstructor
public class OrderHandler {

  private final OrderService orderService;

  public Mono<Order> createOrder(CreateOrderRequest request) {
    log.info("Handler: Creating order for customer {}", request.getCustomerName());

    // Validate item count
    if (!ValidationUtil.isValidItemCount(request.getItems().size())) {
      return Mono.error(
          new IllegalArgumentException("Invalid number of items. Must be between 1 and 100"));
    }

    return orderService.createOrder(request);
  }

  public Mono<Order> getOrder(Long id) {
    log.debug("Handler: Fetching order {}", id);
    return orderService.getOrderById(id);
  }

  public Flux<Order> getAllOrders() {
    log.debug("Handler: Fetching all orders");
    return orderService.getAllOrders();
  }

  public Flux<Order> getOrdersByStatus(OrderStatus status) {
    log.debug("Handler: Fetching orders with status {}", status);
    return orderService.getOrdersByStatus(status);
  }

  public Flux<Order> searchByEmail(String email) {
    log.debug("Handler: Searching orders for email {}", email);

    if (email == null || email.isEmpty()) {
      return Flux.error(new IllegalArgumentException("Email cannot be empty"));
    }

    return orderService.getOrdersByCustomerEmail(email);
  }

  public Mono<Order> updateStatus(Long id, UpdateOrderStatusRequest request) {
    log.info("Handler: Updating order {} status to {}", id, request.getStatus());
    return orderService.updateOrderStatus(id, request.getStatus(), request.getReason());
  }

  public Mono<Void> deleteOrder(Long id) {
    log.info("Handler: Deleting order {}", id);
    return orderService.deleteOrder(id);
  }

  public Mono<Order> recalculateTotal(Long orderId) {
    log.info("Handler: Recalculating total for order {}", orderId);
    return orderService.calculateAndUpdateTotal(orderId);
  }
}
