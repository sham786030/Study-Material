package com.ikea.interview.orderservice.domain.order.model;

import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrderItem {

  private Long id;
  private Long orderId;
  private String productName;
  private Integer quantity;
  private BigDecimal unitPrice;
}
