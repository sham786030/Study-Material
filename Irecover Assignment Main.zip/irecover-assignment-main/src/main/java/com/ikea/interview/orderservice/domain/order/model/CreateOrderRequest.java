package com.ikea.interview.orderservice.domain.order.model;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateOrderRequest {

  @NotBlank(message = "Customer name is required")
  private String customerName;

  @NotBlank(message = "Customer email is required")
  @Email(message = "Invalid email format")
  private String customerEmail;

  @NotEmpty(message = "Order must have at least one item")
  @Valid
  private List<OrderItemRequest> items;
}
