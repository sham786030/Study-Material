package com.ikea.interview.orderservice.domain.order.service;

import com.ikea.interview.orderservice.domain.order.model.CreateOrderRequest;
import com.ikea.interview.orderservice.domain.order.model.Order;
import com.ikea.interview.orderservice.domain.order.model.OrderStatus;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface OrderService {

  Mono<Order> createOrder(CreateOrderRequest request);

  Mono<Order> getOrderById(Long id);

  Flux<Order> getAllOrders();

  Flux<Order> getOrdersByStatus(OrderStatus status);

  Flux<Order> getOrdersByCustomerEmail(String email);

  Mono<Order> updateOrderStatus(Long id, OrderStatus status, String reason);

  Mono<Void> deleteOrder(Long id);

  Mono<Order> calculateAndUpdateTotal(Long orderId);
}
