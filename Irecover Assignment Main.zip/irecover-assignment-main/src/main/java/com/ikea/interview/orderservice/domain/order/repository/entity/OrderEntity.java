package com.ikea.interview.orderservice.domain.order.repository.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table("orders")
public class OrderEntity {

  @Id private Long id;

  @Column("customer_name")
  private String customerName;

  @Column("customer_email")
  private String customerEmail;

  @Column("total_amount")
  private BigDecimal totalAmount;

  @Column("status")
  private String status;

  @Column("created_at")
  private LocalDateTime createdAt;

  @Column("updated_at")
  private LocalDateTime updatedAt;
}
