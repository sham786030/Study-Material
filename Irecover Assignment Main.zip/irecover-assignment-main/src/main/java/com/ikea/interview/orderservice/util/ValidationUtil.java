package com.ikea.interview.orderservice.util;

import com.ikea.interview.orderservice.domain.order.model.OrderStatus;
import java.util.Set;

public class ValidationUtil {

  private static final int MAX_ORDER_ITEMS = 100;
  private static final int MIN_ORDER_ITEMS = 1;

  // Valid state transitions map
  private static final Set<OrderStatus> VALID_TRANSITIONS_FROM_PENDING =
      Set.of(OrderStatus.VALIDATED, OrderStatus.CANCELLED);
  private static final Set<OrderStatus> VALID_TRANSITIONS_FROM_VALIDATED =
      Set.of(OrderStatus.PROCESSING, OrderStatus.CANCELLED);
  private static final Set<OrderStatus> VALID_TRANSITIONS_FROM_PROCESSING =
      Set.of(OrderStatus.FULFILLED, OrderStatus.CANCELLED);

  /**
   * Validates if the order has a valid number of items.
   *
   * @param itemCount number of items in the order
   * @return true if valid, false otherwise
   */
  public static boolean isValidItemCount(int itemCount) {
    return itemCount >= MIN_ORDER_ITEMS && itemCount <= MAX_ORDER_ITEMS;
  }

  /**
   * Validates if a state transition is allowed.
   *
   * @param currentStatus current order status
   * @param targetStatus desired order status
   * @return true if transition is valid
   */
  public static boolean isValidStateTransition(OrderStatus currentStatus, OrderStatus targetStatus) {
    if (currentStatus == targetStatus) {
      return true;
    }

    return switch (currentStatus) {
      case PENDING -> VALID_TRANSITIONS_FROM_PENDING.contains(targetStatus);
      case VALIDATED -> VALID_TRANSITIONS_FROM_VALIDATED.contains(targetStatus);
      case PROCESSING -> VALID_TRANSITIONS_FROM_PROCESSING.contains(targetStatus);
      case FULFILLED, CANCELLED -> false; // Terminal states
    };
  }

  /**
   * Validates email format.
   *
   * @param email email to validate
   * @return true if valid email format
   */
  public static boolean isValidEmail(String email) {
    if (email == null || email.isBlank()) {
      return false;
    }
    return email.matches("^[A-Za-z0-9+_.-]+@(.+)$");
  }
}
