package com.ikea.interview.orderservice.domain.order.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Order {

  private Long id;
  private String customerName;
  private String customerEmail;
  private BigDecimal totalAmount;
  private OrderStatus status;
  private List<OrderItem> items;
  private LocalDateTime createdAt;
  private LocalDateTime updatedAt;
}
