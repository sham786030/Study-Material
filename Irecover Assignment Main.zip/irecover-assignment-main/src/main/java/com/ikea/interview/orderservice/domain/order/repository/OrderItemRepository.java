package com.ikea.interview.orderservice.domain.order.repository;

import com.ikea.interview.orderservice.domain.order.repository.entity.OrderItemEntity;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;

@Repository
public interface OrderItemRepository extends ReactiveCrudRepository<OrderItemEntity, Long> {

  Flux<OrderItemEntity> findByOrderId(Long orderId);
}
