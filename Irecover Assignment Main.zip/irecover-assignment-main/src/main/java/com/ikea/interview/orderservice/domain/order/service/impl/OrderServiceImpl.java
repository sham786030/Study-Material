package com.ikea.interview.orderservice.domain.order.service.impl;

import com.ikea.interview.orderservice.domain.order.exception.InvalidOrderStateException;
import com.ikea.interview.orderservice.domain.order.exception.OrderNotFoundException;
import com.ikea.interview.orderservice.domain.order.mapper.OrderMapper;
import com.ikea.interview.orderservice.domain.order.model.CreateOrderRequest;
import com.ikea.interview.orderservice.domain.order.model.Order;
import com.ikea.interview.orderservice.domain.order.model.OrderStatus;
import com.ikea.interview.orderservice.domain.order.repository.OrderItemRepository;
import com.ikea.interview.orderservice.domain.order.repository.OrderRepository;
import com.ikea.interview.orderservice.domain.order.repository.entity.OrderEntity;
import com.ikea.interview.orderservice.domain.order.repository.entity.OrderItemEntity;
import com.ikea.interview.orderservice.domain.order.service.OrderService;
import com.ikea.interview.orderservice.util.ValidationUtil;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@Service
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {

  private final OrderRepository orderRepository;
  private final OrderItemRepository orderItemRepository;
  private final OrderMapper orderMapper;

  @Override
  public Mono<Order> createOrder(CreateOrderRequest request) {
    log.info("Creating order for customer: {}", request.getCustomerName());

    // Calculate total amount
    BigDecimal totalAmount = calculateTotalAmount(request);

    OrderEntity orderEntity = orderMapper.toEntity(request);
    orderEntity.setTotalAmount(totalAmount);
    orderEntity.setCreatedAt(LocalDateTime.now());
    orderEntity.setUpdatedAt(LocalDateTime.now());

    return orderRepository
        .save(orderEntity)
        .flatMap(
            savedOrder -> {
              List<OrderItemEntity> items =
                  request.getItems().stream()
                      .map(
                          item -> {
                            OrderItemEntity itemEntity = orderMapper.toEntity(item);
                            itemEntity.setOrderId(savedOrder.getId());
                            return itemEntity;
                          })
                      .toList();

              return orderItemRepository
                  .saveAll(items)
                  .collectList()
                  .map(
                      savedItems -> {
                        Order order = orderMapper.toOrder(savedOrder);
                        order.setItems(savedItems.stream().map(orderMapper::toOrderItem).toList());
                        return order;
                      });
            });
  }

  @Override
  public Mono<Order> getOrderById(Long id) {
    log.debug("Fetching order with id: {}", id);
    return orderRepository
        .findById(id)
        .switchIfEmpty(Mono.error(new OrderNotFoundException(id)))
        .flatMap(this::enrichWithItems);
  }

  @Override
  public Flux<Order> getAllOrders() {
    log.debug("Fetching all orders");
    return orderRepository.findAll().flatMap(this::enrichWithItems);
  }

  @Override
  public Flux<Order> getOrdersByStatus(OrderStatus status) {
    log.debug("Fetching orders with status: {}", status);
    return orderRepository.findByStatus(status.name()).flatMap(this::enrichWithItems);
  }

  @Override
  public Flux<Order> getOrdersByCustomerEmail(String email) {
    log.debug("Fetching orders for customer: {}", email);
    return orderRepository.findByCustomerEmail(email).flatMap(this::enrichWithItems);
  }

  @Override
  public Mono<Order> updateOrderStatus(Long id, OrderStatus newStatus, String reason) {
    log.info("Updating order {} status to: {}", id, newStatus);

    return orderRepository
        .findById(id)
        .switchIfEmpty(Mono.error(new OrderNotFoundException(id)))
        .flatMap(
            order -> {
              OrderStatus currentStatus = OrderStatus.valueOf(order.getStatus());

              if (currentStatus == newStatus) {
                log.warn("Order {} already in status {}", id, newStatus);
                return Mono.just(order);
              }

              if (!ValidationUtil.isValidStateTransition(currentStatus, newStatus)) {
                log.warn(
                    "Invalid state transition from {} to {} - proceeding anyway",
                    currentStatus,
                    newStatus);
              }

              order.setStatus(newStatus.name());
              order.setUpdatedAt(LocalDateTime.now());

              return orderRepository.save(order);
            })
        .flatMap(this::enrichWithItems);
  }

  @Override
  public Mono<Void> deleteOrder(Long id) {
    log.info("Deleting order: {}", id);
    return orderRepository
        .findById(id)
        .switchIfEmpty(Mono.error(new OrderNotFoundException(id)))
        .flatMap(
            order -> orderItemRepository.findByOrderId(id).flatMap(orderItemRepository::delete).then())
        .then(orderRepository.deleteById(id));
  }

  @Override
  public Mono<Order> calculateAndUpdateTotal(Long orderId) {
    log.info("Recalculating total for order: {}", orderId);
    return orderRepository
        .findById(orderId)
        .switchIfEmpty(Mono.error(new OrderNotFoundException(orderId)))
        .flatMap(
            order ->
                orderItemRepository
                    .findByOrderId(orderId)
                    .collectList()
                    .flatMap(
                        items -> {
                          BigDecimal total =
                              items.stream()
                                  .map(
                                      item ->
                                          item.getUnitPrice()
                                              .multiply(BigDecimal.valueOf(item.getQuantity())))
                                  .reduce(BigDecimal.ZERO, BigDecimal::add);

                          order.setTotalAmount(total);
                          order.setUpdatedAt(LocalDateTime.now());
                          return orderRepository.save(order);
                        }))
        .flatMap(this::enrichWithItems);
  }

  private BigDecimal calculateTotalAmount(CreateOrderRequest request) {
    return request.getItems().stream()
        .map(item -> item.getUnitPrice().multiply(BigDecimal.valueOf(item.getQuantity())))
        .reduce(BigDecimal.ZERO, BigDecimal::add);
  }

  private Mono<Order> enrichWithItems(OrderEntity orderEntity) {
    return orderItemRepository
        .findByOrderId(orderEntity.getId())
        .map(orderMapper::toOrderItem)
        .collectList()
        .map(
            items -> {
              Order order = orderMapper.toOrder(orderEntity);
              order.setItems(items);
              return order;
            });
  }
}
