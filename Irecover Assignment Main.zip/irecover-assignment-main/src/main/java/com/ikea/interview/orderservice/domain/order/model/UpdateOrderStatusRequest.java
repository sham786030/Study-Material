package com.ikea.interview.orderservice.domain.order.model;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateOrderStatusRequest {

  @NotNull(message = "Status is required")
  private OrderStatus status;

  private String reason;
}
