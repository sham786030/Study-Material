package com.ikea.interview.orderservice.domain.order.service.impl;

import com.ikea.interview.orderservice.domain.order.model.OrderStatistics;
import com.ikea.interview.orderservice.domain.order.model.OrderStatus;
import com.ikea.interview.orderservice.domain.order.repository.OrderRepository;
import com.ikea.interview.orderservice.domain.order.service.OrderStatisticsService;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.atomic.AtomicReference;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Slf4j
@Service
@RequiredArgsConstructor
public class OrderStatisticsServiceImpl implements OrderStatisticsService {

  private static final Duration CACHE_TTL = Duration.ofMinutes(5);

  private final OrderRepository orderRepository;

  private final AtomicReference<OrderStatistics> cachedStatistics = new AtomicReference<>();
  private volatile Instant cacheTimestamp = Instant.EPOCH;

  @Override
  public Mono<OrderStatistics> getStatistics() {
    if (isCacheValid()) {
      log.debug("Returning cached statistics");
      return Mono.justOrEmpty(cachedStatistics.get());
    }

    log.debug("Cache miss - computing statistics");
    return computeStatistics()
        .doOnNext(
            stats -> {
              cachedStatistics.set(stats);
              cacheTimestamp = Instant.now();
            });
  }

  @Override
  public Mono<OrderStatistics> getStatisticsForCustomer(String email) {
    log.debug("Computing statistics for customer: {}", email);
    return orderRepository
        .findByCustomerEmail(email)
        .collectList()
        .map(
            orders -> {
              long total = orders.size();
              long pending =
                  orders.stream()
                      .filter(o -> OrderStatus.PENDING.name().equals(o.getStatus()))
                      .count();
              long fulfilled =
                  orders.stream()
                      .filter(o -> OrderStatus.FULFILLED.name().equals(o.getStatus()))
                      .count();
              long cancelled =
                  orders.stream()
                      .filter(o -> OrderStatus.CANCELLED.name().equals(o.getStatus()))
                      .count();

              BigDecimal totalRevenue =
                  orders.stream()
                      .filter(o -> OrderStatus.FULFILLED.name().equals(o.getStatus()))
                      .map(o -> o.getTotalAmount() != null ? o.getTotalAmount() : BigDecimal.ZERO)
                      .reduce(BigDecimal.ZERO, BigDecimal::add);

              BigDecimal avgValue =
                  total > 0
                      ? totalRevenue.divide(BigDecimal.valueOf(total), 2, RoundingMode.HALF_UP)
                      : BigDecimal.ZERO;

              return OrderStatistics.builder()
                  .totalOrders(total)
                  .pendingOrders(pending)
                  .fulfilledOrders(fulfilled)
                  .cancelledOrders(cancelled)
                  .totalRevenue(totalRevenue)
                  .averageOrderValue(avgValue)
                  .build();
            });
  }

  @Override
  public void invalidateCache() {
    log.debug("Invalidating statistics cache");
    cacheTimestamp = Instant.EPOCH;
  }

  private boolean isCacheValid() {
    return cachedStatistics.get() != null
        && Instant.now().isBefore(cacheTimestamp.plus(CACHE_TTL));
  }

  private Mono<OrderStatistics> computeStatistics() {
    return orderRepository
        .findAll()
        .collectList()
        .map(
            orders -> {
              long total = orders.size();
              long pending =
                  orders.stream()
                      .filter(o -> OrderStatus.PENDING.name().equals(o.getStatus()))
                      .count();
              long fulfilled =
                  orders.stream()
                      .filter(o -> OrderStatus.FULFILLED.name().equals(o.getStatus()))
                      .count();
              long cancelled =
                  orders.stream()
                      .filter(o -> OrderStatus.CANCELLED.name().equals(o.getStatus()))
                      .count();

              BigDecimal totalRevenue =
                  orders.stream()
                      .filter(o -> OrderStatus.FULFILLED.name().equals(o.getStatus()))
                      .map(o -> o.getTotalAmount() != null ? o.getTotalAmount() : BigDecimal.ZERO)
                      .reduce(BigDecimal.ZERO, BigDecimal::add);

              BigDecimal avgValue = BigDecimal.ZERO;
              if (fulfilled > 0) {
                avgValue = totalRevenue.divide(BigDecimal.valueOf(fulfilled), 2, RoundingMode.HALF_UP);
              }

              return OrderStatistics.builder()
                  .totalOrders(total)
                  .pendingOrders(pending)
                  .fulfilledOrders(fulfilled)
                  .cancelledOrders(cancelled)
                  .totalRevenue(totalRevenue)
                  .averageOrderValue(avgValue)
                  .build();
            });
  }
}
