package com.ikea.interview.orderservice.domain.order.mapper;

import com.ikea.interview.orderservice.domain.order.model.CreateOrderRequest;
import com.ikea.interview.orderservice.domain.order.model.Order;
import com.ikea.interview.orderservice.domain.order.model.OrderItem;
import com.ikea.interview.orderservice.domain.order.model.OrderItemRequest;
import com.ikea.interview.orderservice.domain.order.model.OrderStatus;
import com.ikea.interview.orderservice.domain.order.repository.entity.OrderEntity;
import com.ikea.interview.orderservice.domain.order.repository.entity.OrderItemEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

@Mapper(componentModel = "spring")
public interface OrderMapper {

  @Mapping(target = "status", source = "status", qualifiedByName = "stringToStatus")
  @Mapping(target = "items", ignore = true)
  Order toOrder(OrderEntity entity);

  @Mapping(target = "status", source = "status", qualifiedByName = "statusToString")
  @Mapping(target = "id", ignore = true)
  @Mapping(target = "createdAt", ignore = true)
  @Mapping(target = "updatedAt", ignore = true)
  OrderEntity toEntity(Order order);

  @Mapping(target = "id", ignore = true)
  @Mapping(target = "status", constant = "PENDING")
  @Mapping(target = "totalAmount", ignore = true)
  @Mapping(target = "createdAt", ignore = true)
  @Mapping(target = "updatedAt", ignore = true)
  OrderEntity toEntity(CreateOrderRequest request);

  OrderItem toOrderItem(OrderItemEntity entity);

  @Mapping(target = "id", ignore = true)
  @Mapping(target = "orderId", ignore = true)
  OrderItemEntity toEntity(OrderItemRequest request);

  @Mapping(target = "id", ignore = true)
  OrderItemEntity toEntity(OrderItem item);

  @Named("stringToStatus")
  default OrderStatus stringToStatus(String status) {
    if (status == null) {
      return null;
    }
    return OrderStatus.valueOf(status);
  }

  @Named("statusToString")
  default String statusToString(OrderStatus status) {
    if (status == null) {
      return null;
    }
    return status.name();
  }
}
