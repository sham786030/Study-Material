package com.ikea.interview.orderservice.domain.order.exception;

public class OrderNotFoundException extends RuntimeException {

  public OrderNotFoundException(Long id) {
    super("Order not found with id: " + id);
  }

  public OrderNotFoundException(String message) {
    super(message);
  }
}
