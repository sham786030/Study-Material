package com.ikea.interview.orderservice.domain.order.service;

import com.ikea.interview.orderservice.domain.order.model.OrderStatistics;
import reactor.core.publisher.Mono;

public interface OrderStatisticsService {

  Mono<OrderStatistics> getStatistics();

  Mono<OrderStatistics> getStatisticsForCustomer(String email);

  void invalidateCache();
}
