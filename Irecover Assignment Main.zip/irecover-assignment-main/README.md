# iRecover Assignment - Order Processing Service

A Spring Boot WebFlux application for managing orders. This is a coding assignment for interview candidates.

## 🎯 Assignment Overview

This project is an **Order Processing Service** with intentional bugs that need to be identified and fixed. Your task is to:

1. **Review** the codebase and understand its architecture
2. **Run** the tests and identify failing tests
3. **Debug** and fix the issues
4. **Explain** your findings and fixes

## 🏗️ Architecture

The project follows a **Domain-Driven Design** structure similar to our production services:

```
com.ikea.interview.orderservice/
├── config/                    # Configuration classes
├── domain/
│   └── order/                 # Order domain
│       ├── controller/        # REST endpoints
│       ├── handler/           # Business orchestration
│       ├── service/           # Business logic
│       ├── repository/        # Data access
│       ├── model/             # Domain models & DTOs
│       ├── mapper/            # MapStruct mappers
│       └── exception/         # Domain exceptions
├── exception/                 # Global exception handling
└── util/                      # Utility classes
```

## 🛠️ Tech Stack

- **Java 21**
- **Spring Boot 3.4** (WebFlux - Reactive)
- **R2DBC** with H2 in-memory database
- **MapStruct** for object mapping
- **Lombok** for boilerplate reduction
- **JUnit 5** + **Reactor Test** for testing

## 📋 Domain: Order Processing

This service manages the lifecycle of customer orders from creation to fulfillment.

### Order Lifecycle

An order progresses through distinct states, each representing a stage in the fulfillment process:

```
┌─────────┐     ┌───────────┐     ┌────────────┐     ┌───────────┐
│ PENDING │────▶│ VALIDATED │────▶│ PROCESSING │────▶│ FULFILLED │
└─────────┘     └───────────┘     └────────────┘     └───────────┘
     │               │                  │
     │               │                  │
     ▼               ▼                  ▼
┌───────────────────────────────────────────────────────────────┐
│                        CANCELLED                              │
└───────────────────────────────────────────────────────────────┘
```

### State Descriptions

| State | Description | Next Valid States |
|-------|-------------|-------------------|
| **PENDING** | Order just created, awaiting validation | `VALIDATED`, `CANCELLED` |
| **VALIDATED** | Order validated (items available, payment confirmed) | `PROCESSING`, `CANCELLED` |
| **PROCESSING** | Order being prepared/packed in warehouse | `FULFILLED`, `CANCELLED` |
| **FULFILLED** | Order completed and delivered to customer | *(terminal state)* |
| **CANCELLED** | Order cancelled at any stage | *(terminal state)* |

### Why Orders Get Cancelled

An order can be cancelled from any non-terminal state for various reasons:
- **From PENDING**: Customer changes mind, payment fails, invalid address
- **From VALIDATED**: Items went out of stock, fraud detection triggered
- **From PROCESSING**: Customer request, damaged during packing, shipping issues

### Business Rules

1. **Forward-only progression**: Orders can only move forward in the workflow (except for cancellation)
2. **No resurrection**: Once `FULFILLED` or `CANCELLED`, an order cannot change state
3. **Cancellation always allowed**: Any active order can be cancelled (until fulfilled)
4. **No skipping states**: Cannot jump from `PENDING` directly to `FULFILLED`

### Order Structure

```json
{
  "id": 1,
  "customerName": "John Doe",
  "customerEmail": "john@example.com",
  "status": "PENDING",
  "totalAmount": 149.97,
  "items": [
    {
      "productName": "KALLAX Shelf",
      "quantity": 2,
      "unitPrice": 49.99
    },
    {
      "productName": "LACK Table",
      "quantity": 1,
      "unitPrice": 49.99
    }
  ],
  "createdAt": "2026-02-11T10:00:00",
  "updatedAt": "2026-02-11T10:00:00"
}
```

### API Endpoints

| Method | Endpoint                          | Description              |
|--------|-----------------------------------|--------------------------|
| POST   | `/api/v1/orders`                  | Create a new order       |
| GET    | `/api/v1/orders`                  | List all orders          |
| GET    | `/api/v1/orders/{id}`             | Get order by ID          |
| GET    | `/api/v1/orders?status={status}`  | Filter by status         |
| GET    | `/api/v1/orders?email={email}`    | Filter by customer email |
| PATCH  | `/api/v1/orders/{id}/status`      | Update order status      |
| DELETE | `/api/v1/orders/{id}`             | Delete an order          |
| POST   | `/api/v1/orders/{id}/recalculate` | Recalculate order total  |

## 🚀 Getting Started

### Prerequisites

- Java 21
- Maven 3.8+

### Build

```bash
./mvnw clean compile
```

### Run Tests

```bash
./mvnw test
```

### Run Application

```bash
./mvnw spring-boot:run
```

The application will start on `http://localhost:8080`

### Test with cURL

```bash
# Create an order
curl -X POST http://localhost:8080/api/v1/orders \
  -H "Content-Type: application/json" \
  -d '{
    "customerName": "John Doe",
    "customerEmail": "john@example.com",
    "items": [
      {
        "productName": "KALLAX Shelf",
        "quantity": 2,
        "unitPrice": 49.99
      }
    ]
  }'

# Get all orders
curl http://localhost:8080/api/v1/orders

# Get order by ID
curl http://localhost:8080/api/v1/orders/1
```

### 🐳 Docker (Production Deployment)

Build and run the application using Docker:

```bash
# Build Docker image
docker build -t irecover-assignment .

# Run container
docker run -p 8080:8080 irecover-assignment

# Or use docker-compose
docker-compose up --build
```

Verify the application is healthy:
```bash
curl http://localhost:8080/actuator/health
```

## ✅ Assignment Tasks

### Task 1: Run Tests
Run the test suite and observe which tests fail:
```bash
./mvnw test
```

### Task 2: Identify Bugs
The failing tests hint at bugs in the code. Find and document the bugs.

### Task 3: Fix the Bugs
Fix the identified bugs and ensure all tests pass.

### Task 4: Docker Deployment
Build and run the application in Docker. Ensure it starts successfully and responds to health checks.

### Task 5: Explain
Be prepared to explain:
- What bugs you found
- Why they occurred
- How you fixed them
- Any edge cases you considered

## 📝 Evaluation Criteria

- **Bug identification**: Finding the intentional bugs
- **Code understanding**: Understanding the reactive patterns and architecture
- **Problem-solving**: Approach to debugging and fixing issues
- **Code quality**: Clean, maintainable fixes
- **Communication**: Clear explanation of findings

## ⏱️ Time Limit

You have **60-90 minutes** to complete this assignment.

---

Good luck! 🍀
